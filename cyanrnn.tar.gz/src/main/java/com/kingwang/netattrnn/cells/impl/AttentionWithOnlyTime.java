/**   
 * @package	com.kingwang.cdmrnn.rnn
 * @File		Attention.java
 * @Crtdate	Sep 28, 2016
 *
 * Copyright (c) 2016 by <a href="mailto:wangyongqing.casia@gmail.com">King Wang</a>.   
 */
package com.kingwang.netattrnn.cells.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Map;

import org.jblas.DoubleMatrix;
import org.jblas.MatrixFunctions;

import com.kingwang.netattrnn.batchderv.BatchDerivative;
import com.kingwang.netattrnn.batchderv.impl.AttWithCovBatchDerivative;
import com.kingwang.netattrnn.cells.Cell;
import com.kingwang.netattrnn.cells.Operator;
import com.kingwang.netattrnn.comm.utils.FileUtil;
import com.kingwang.netattrnn.cons.AlgConsHSoftmax;
import com.kingwang.netattrnn.utils.Activer;
import com.kingwang.netattrnn.utils.LoadTypes;
import com.kingwang.netattrnn.utils.MatIniter;
import com.kingwang.netattrnn.utils.MatIniter.Type;

/**
 *
 * @author King Wang
 * 
 * Sep 28, 2016 3:19:24 PM
 * @version 1.0
 */
public class AttentionWithOnlyTime extends Operator implements Cell, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3581712325656989072L;
	
	public DoubleMatrix Wtt;
	public DoubleMatrix Wst;
	public DoubleMatrix Wxt;
	public DoubleMatrix Wdt;
	public DoubleMatrix bt;
	
	public DoubleMatrix hdWtt;
	public DoubleMatrix hdWst;
	public DoubleMatrix hdWxt;
	public DoubleMatrix hdWdt;
	public DoubleMatrix hdbt;
	
	public DoubleMatrix hd2Wtt;
	public DoubleMatrix hd2Wst;
	public DoubleMatrix hd2Wxt;
	public DoubleMatrix hd2Wdt;
	public DoubleMatrix hd2bt;
	
	public DoubleMatrix V;
	public DoubleMatrix W;
	public DoubleMatrix U;
	public DoubleMatrix Z;
	public DoubleMatrix bs;
	
	public DoubleMatrix hdV;
	public DoubleMatrix hdW;
	public DoubleMatrix hdU;
	public DoubleMatrix hdZ;
	public DoubleMatrix hdbs;

	public DoubleMatrix hd2V;
	public DoubleMatrix hd2W;
	public DoubleMatrix hd2U;
	public DoubleMatrix hd2Z;
	public DoubleMatrix hd2bs;
	
	public DoubleMatrix Wvv;
	public DoubleMatrix Wav;
	public DoubleMatrix Whv;
	public DoubleMatrix Wtv;
	public DoubleMatrix bv;
	
	public DoubleMatrix hdWvv;
	public DoubleMatrix hdWav;
	public DoubleMatrix hdWhv;
	public DoubleMatrix hdWtv;
	public DoubleMatrix hdbv;
	
	public DoubleMatrix hd2Wvv;
	public DoubleMatrix hd2Wav;
	public DoubleMatrix hd2Whv;
	public DoubleMatrix hd2Wtv;
	public DoubleMatrix hd2bv;
	
	private int hiddenSize = 0;
	private int attSize = 0;
	private int covSize = 0;
	
	public AttentionWithOnlyTime(int inDynSize, int inFixedSize, int attSize, int hiddenSize
			, int covSize, MatIniter initer) {
		hdV = new DoubleMatrix(1, attSize);
		hdW = new DoubleMatrix(hiddenSize, attSize);
		hdU = new DoubleMatrix(attSize, attSize);
		hdZ = new DoubleMatrix(covSize, attSize);
		hdbs = new DoubleMatrix(1, attSize);
		
		hd2V = new DoubleMatrix(1, attSize);
		hd2W = new DoubleMatrix(hiddenSize, attSize);
		hd2U = new DoubleMatrix(attSize, attSize);
		hd2Z = new DoubleMatrix(covSize, attSize);
		hd2bs = new DoubleMatrix(1, attSize);
		
		hdWtt = new DoubleMatrix(hiddenSize, hiddenSize);        
		hdWst = new DoubleMatrix(attSize, hiddenSize);
        hdWxt = new DoubleMatrix(inDynSize, hiddenSize);
        hdWdt = new DoubleMatrix(inFixedSize, hiddenSize);
        hdbt = new DoubleMatrix(1, hiddenSize);
        
        hd2Wtt = new DoubleMatrix(hiddenSize, hiddenSize);        
        hd2Wst = new DoubleMatrix(attSize, hiddenSize);
        hd2Wxt = new DoubleMatrix(inDynSize, hiddenSize);
        hd2Wdt = new DoubleMatrix(inFixedSize, hiddenSize);
        hd2bt = new DoubleMatrix(1, hiddenSize);
		
		if (initer.getType() == Type.Uniform) {
			Wtt = initer.uniform(hiddenSize, hiddenSize);
        	Wst = initer.uniform(attSize, hiddenSize);
        	Wxt = initer.uniform(inDynSize, hiddenSize);
        	Wdt = initer.uniform(inFixedSize, hiddenSize);
        	bt = initer.uniform(1, hiddenSize);
			
			V = initer.uniform(1, attSize);
			W = initer.uniform(hiddenSize, attSize);
			U = initer.uniform(attSize, attSize);
			Z = initer.uniform(covSize, attSize);
			bs = new DoubleMatrix(1, attSize).add(AlgConsHSoftmax.biasInitVal);
        } else if (initer.getType() == Type.Gaussian) {
        	Wtt = initer.gaussian(hiddenSize, hiddenSize);
        	Wst = initer.gaussian(attSize, hiddenSize);
        	Wxt = initer.gaussian(inDynSize, hiddenSize);
        	Wdt = initer.gaussian(inFixedSize, hiddenSize);
        	bt = initer.gaussian(1, hiddenSize);
        	
        	V = initer.gaussian(1, attSize);
    		W = initer.gaussian(hiddenSize, attSize);
    		U = initer.gaussian(attSize, attSize);
    		Z = initer.gaussian(covSize, attSize);
    		bs = new DoubleMatrix(1, attSize).add(AlgConsHSoftmax.biasInitVal);
        } else if (initer.getType() == Type.SVD) {
        	Wtt = initer.svd(hiddenSize, hiddenSize);
        	Wst = initer.svd(attSize, hiddenSize);
        	Wxt = initer.svd(inDynSize, hiddenSize);
        	Wdt = initer.svd(inFixedSize, hiddenSize);
        	bt = initer.svd(1, hiddenSize);
        	
        	V = initer.svd(1, attSize);
    		W = initer.svd(hiddenSize, attSize);
    		U = initer.svd(attSize, attSize);
    		Z = initer.svd(covSize, attSize);
    		bs = new DoubleMatrix(1, attSize).add(AlgConsHSoftmax.biasInitVal);
        } else if(initer.getType() == Type.Test) {
        	V = new DoubleMatrix(1, attSize).add(0.1);
    		W = new DoubleMatrix(hiddenSize, attSize).add(0.1);
    		U = new DoubleMatrix(attSize, attSize).add(0.2);
    		Z = new DoubleMatrix(covSize, attSize).add(0.2);
    		bs = new DoubleMatrix(1, attSize).add(0.4);
        }
		
		initCoverage(inDynSize, inFixedSize, attSize, hiddenSize, covSize, initer);
		
		this.hiddenSize = hiddenSize;
		this.attSize = attSize;
		this.covSize = covSize;
	}
	
	private void initCoverage(int inDynSize, int inFixedSize, int attSize, int hiddenSize
								, int covSize, MatIniter initer) {
		hdWvv = new DoubleMatrix(covSize, covSize);        
        hdWav = new DoubleMatrix(1, covSize);
        hdWhv = new DoubleMatrix(attSize, covSize);
        hdWtv = new DoubleMatrix(hiddenSize, covSize);
        hdbv = new DoubleMatrix(1, covSize);
        
        hd2Wvv = new DoubleMatrix(covSize, covSize);        
        hd2Wav = new DoubleMatrix(1, covSize);
        hd2Whv = new DoubleMatrix(attSize, covSize);
        hd2Wtv = new DoubleMatrix(hiddenSize, covSize);
        hd2bv = new DoubleMatrix(1, covSize);
		
		if (initer.getType() == Type.Uniform) {
			Wvv = initer.uniform(covSize, covSize);
        	Wav = initer.uniform(1, covSize);
        	Whv = initer.uniform(attSize, covSize);
        	Wtv = initer.uniform(hiddenSize, covSize);
        } else if (initer.getType() == Type.Gaussian) {
        	Wvv = initer.gaussian(covSize, covSize);
        	Wav = initer.gaussian(1, covSize);
        	Whv = initer.gaussian(attSize, covSize);
        	Wtv = initer.gaussian(hiddenSize, covSize);
        } else if (initer.getType() == Type.SVD) {
        	Wvv = initer.svd(covSize, covSize);
        	Wav = initer.svd(1, covSize);
        	Whv = initer.svd(attSize, covSize);
        	Wtv = initer.svd(hiddenSize, covSize);
        } 
		bv = new DoubleMatrix(1, covSize).add(AlgConsHSoftmax.biasInitVal);
	}
	
	public void active(int t, Map<String, DoubleMatrix> acts, double... params) {
	
		activeCoverage(t, acts);
		
		DoubleMatrix prevT = null;
		if(t>0) {
			prevT = acts.get("t"+(t-1));
		} else {
			prevT = DoubleMatrix.zeros(1, hiddenSize);
		}
		int eSize = Math.min(t+1, AlgConsHSoftmax.windowSize);
		DoubleMatrix eWeight = new DoubleMatrix(eSize);
		
		DoubleMatrix vecV = acts.get("v"+t);
		DoubleMatrix gs = new DoubleMatrix(eSize, attSize);
		int bsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+1);
		for(int k=bsIdx; k<t+1; k++) { //TODO:here is the problem
			DoubleMatrix hk = acts.get("h"+k);
			DoubleMatrix gsk = Activer.tanh(prevT.mmul(W).add(hk.mmul(U))
								.add(vecV.getRow(k-bsIdx).mmul(Z)).add(bs));
			gs.putRow(k-bsIdx, gsk);
			eWeight.putRow(k-bsIdx, V.mmul(gsk.transpose()));
		}
		acts.put("gs"+t, gs);
		
		DoubleMatrix alpha = Activer.softmax(eWeight.transpose()).transpose();
		acts.put("alpha"+t, alpha);
		
		DoubleMatrix s = new DoubleMatrix(1, attSize);
		for(int k=bsIdx; k<t+1; k++) {
			DoubleMatrix hk = acts.get("h"+k);
			s = s.add(hk.mul(alpha.get(k-bsIdx)));
		}
		acts.put("s"+t, s);
		
    	DoubleMatrix x = acts.get("x"+t);
    	DoubleMatrix fixedFeat = acts.get("fixedFeat" + t);
    	
    	DoubleMatrix vecT = Activer.logistic(x.mmul(Wxt).add(fixedFeat.mmul(Wdt)).add(prevT.mmul(Wtt))
    							.add(s.mmul(Wst)).add(bt));
    	acts.put("t"+t, vecT);
		
	}
	
	private void activeCoverage(int t, Map<String, DoubleMatrix> acts) {
		DoubleMatrix prevV = null;
		DoubleMatrix prevT = null;
		DoubleMatrix prevAlpha = null;
		if(t>0) {
			prevT = acts.get("t"+(t-1));
			prevV = acts.get("v"+(t-1));
			prevAlpha = acts.get("alpha"+(t-1));
		} else {
			prevT = DoubleMatrix.zeros(1, hiddenSize);
		}
    	
		int eSize = Math.min(t+1, AlgConsHSoftmax.windowSize);
		int bsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+1);
		DoubleMatrix vecV = new DoubleMatrix(eSize, covSize);
		int biasPos = bsIdx>0?1:0;
		for(int k=bsIdx; k<t+1; k++) {
			DoubleMatrix hk = acts.get("h"+k);
			if(k<t) {
				vecV.putRow(k-bsIdx, Activer.logistic(prevV.getRow(k-bsIdx+biasPos).mmul(Wvv)
										.add(Wav.mul(prevAlpha.get(k-bsIdx+biasPos)))
										.add(hk.mmul(Whv)).add(prevT.mmul(Wtv)).add(bv)));
			} else {
				vecV.putRow(k-bsIdx, Activer.logistic(hk.mmul(Whv).add(prevT.mmul(Wtv)).add(bv)));
			}
		}
		
    	acts.put("v"+t, vecV);
	}
	
	public void bptt(Map<String, DoubleMatrix> acts, int lastT, Cell... cell) {

		OutputLayerWithOnlyTime outLayer = (OutputLayerWithOnlyTime)cell[0];
		
		for (int t = lastT; t > -1; t--) {
//			DoubleMatrix deltaY = acts.get("dy"+t);
//			DoubleMatrix deltaCls = acts.get("dCls"+t);
			DoubleMatrix deltaD = acts.get("dd"+t);
			//get cidx
//			DoubleMatrix c = acts.get("cls" + t);
//    		int cidx = 0;
//    		for(; cidx<c.length; cidx++) {
//    			if(c.get(cidx)==1) {
//    				break;
//    			}
//    		}
			
    		int bsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+1);
    		int eSize = Math.min(t+1, AlgConsHSoftmax.windowSize);
    		DoubleMatrix lateDat = null;
        	DoubleMatrix lateDgs = null;
        	DoubleMatrix lateDgV = null;
        	DoubleMatrix lateVecV = null;
        	DoubleMatrix lateDgVecV = null;
        	if(t<lastT) {
        		lateDat = acts.get("dAt"+(t+1));
        		lateDgs = acts.get("dgs"+(t+1));
        		lateDgV = acts.get("dgV"+(t+1));
        		lateVecV = acts.get("v"+(t+1));
        		lateDgVecV = lateDgV.mul(deriveExp(lateVecV));
        	}
    		
    		// delta t
//            DoubleMatrix deltaT = deltaY.mmul(outLayer.Wty[cidx].transpose())
//            						.add(deltaCls.mmul(outLayer.Wtc.transpose()))
//            						.add(deltaD.mmul(outLayer.Wtd.transpose()));
        	DoubleMatrix deltaT = deltaD.mmul(outLayer.Wtd.transpose());
            if(t<lastT) {
            	int lateESize = Math.min(t+2, AlgConsHSoftmax.windowSize);
            	deltaT = deltaT.add(
            					lateDat.mmul(Wtt.transpose())
            					.add(DoubleMatrix.ones(1, lateESize).mmul(lateDgs.mmul(W.transpose())))
            					.add(DoubleMatrix.ones(1, lateESize).mmul(lateDgVecV.mmul(Wtv.transpose())))
            					);
            }
            DoubleMatrix vecT = acts.get("t"+t);
            DoubleMatrix deltaAt = deltaT.mul(deriveExp(vecT));
            acts.put("dAt" + t, deltaAt);

            // delta s
//            DoubleMatrix deltaS = deltaY.mmul(outLayer.Wsy[cidx].transpose())
//					            		.add(deltaCls.mmul(outLayer.Wsc.transpose()))
//					            		.add(deltaAt.mmul(Wst.transpose()))
//					            		.add(deltaD.mmul(outLayer.Wsd.transpose()));
            DoubleMatrix deltaS = deltaAt.mmul(Wst.transpose())
            						.add(deltaD.mmul(outLayer.Wsd.transpose()));
            acts.put("ds"+t, deltaS);
			
			// delta alpha
            DoubleMatrix alpha = acts.get("alpha"+t);
			DoubleMatrix deltaAlpha = new DoubleMatrix(eSize);
			for(int j=bsIdx; j<t+1; j++) {
				DoubleMatrix hj = acts.get("h"+j);
				deltaAlpha.put(j-bsIdx, deltaS.mmul(hj.transpose()).get(0));
			}
			if(t<lastT) {
				int lateBsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+2);
				int lateBiasPos = lateBsIdx>0?1:0;
				for(int k=lateBiasPos; k<eSize; k++) {
        			deltaAlpha.put(k, deltaAlpha.get(k)+
        					lateDgVecV.getRow(k-lateBiasPos).mmul(Wav.transpose()).get(0)
        					);
            	}
			}
			
			// delta e
			DoubleMatrix deltaE = deltaAlpha.mul(alpha).sub(alpha.mmul(deltaAlpha.transpose()).mmul(alpha));
			acts.put("de"+t, deltaE);
			
			// delta gs
			DoubleMatrix gs = acts.get("gs"+t);
			DoubleMatrix deltaGs = new DoubleMatrix(eSize, attSize);
			for(int k=bsIdx; k<t+1; k++) {
				deltaGs.putRow(k-bsIdx, V.mul(deriveTanh(gs.getRow(k-bsIdx)))
											.mul(deltaE.get(k-bsIdx))
											);
			}
			acts.put("dgs"+t, deltaGs);
			
			// delta gV
			DoubleMatrix deltaGV = deltaGs.mmul(Z.transpose());
			if(t<lastT) {
				int lateBsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+2);
				int lateBiasPos = lateBsIdx>0?1:0;
				for(int k=lateBiasPos; k<eSize; k++) {
					deltaGV.putRow(k, deltaGV.getRow(k).add(
							lateDgVecV.getRow(k-lateBiasPos).mmul(Wvv.transpose())
							));
//        			deltaGV.putRow(k-bsIdx+biasPos, deltaGV.getRow(k-bsIdx+biasPos).add(
//        					lateDgV.getRow(k-bsIdx).mul(lateDgVecV.getRow(k-bsIdx)).mmul(Wvv.transpose())
//        					));
            	}
			}
			acts.put("dgV"+t, deltaGV);
    	}
		
		calcWeightsGradient(acts, lastT);
 		calcWeightsCovGradient(acts, lastT);
	}
	
	private void calcWeightsGradient(Map<String, DoubleMatrix> acts, int lastT) {
		
		DoubleMatrix dWxt = new DoubleMatrix(Wxt.rows, Wxt.columns);
    	DoubleMatrix dWdt = new DoubleMatrix(Wdt.rows, Wdt.columns);
    	DoubleMatrix dWtt = new DoubleMatrix(Wtt.rows, Wtt.columns);
    	DoubleMatrix dWst = new DoubleMatrix(Wst.rows, Wst.columns);
    	DoubleMatrix dbt = new DoubleMatrix(bt.rows, bt.columns);
		
		DoubleMatrix dV = new DoubleMatrix(V.rows, V.columns);
		DoubleMatrix dW = new DoubleMatrix(W.rows, W.columns);
		DoubleMatrix dU = new DoubleMatrix(U.rows, U.columns);
		DoubleMatrix dZ = new DoubleMatrix(Z.rows, Z.columns);
		DoubleMatrix dbs = new DoubleMatrix(bs.rows, bs.columns);
		
		for(int t=0; t<lastT+1; t++) {
			DoubleMatrix deltaE = acts.get("de"+t);
			DoubleMatrix deltaGs = acts.get("dgs"+t);
			DoubleMatrix deltaAt = acts.get("dAt"+t);
			
			int bsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+1);
			int eSize = Math.min(t+1, AlgConsHSoftmax.windowSize);
			
			DoubleMatrix prevT = null;
			if(t>0) {
				prevT = acts.get("t"+(t-1)).transpose();
			} else {
				prevT = DoubleMatrix.zeros(1, hiddenSize).transpose();
			}
			dW = dW.add(prevT.mmul(DoubleMatrix.ones(1,eSize)).mmul(deltaGs));

			DoubleMatrix gs = acts.get("gs"+t);
			DoubleMatrix vecV = acts.get("v"+t);
			for(int k=bsIdx; k<t+1; k++) {
				DoubleMatrix hk = acts.get("h"+k).transpose();
				dU = dU.add(hk.mmul(deltaGs.getRow(k-bsIdx)));
				dV = dV.add(gs.getRow(k-bsIdx).mul(deltaE.get(k-bsIdx)));
				dZ = dZ.add(vecV.getRow(k-bsIdx).transpose().mmul(deltaGs.getRow(k-bsIdx)));
				dbs = dbs.add(deltaGs.getRow(k-bsIdx));
			}
			
			DoubleMatrix x = acts.get("x" + t).transpose();
            DoubleMatrix fixedFeat = acts.get("fixedFeat" + t).transpose();
            DoubleMatrix s = acts.get("s" + t).transpose();
            
			dWxt = dWxt.add(x.mmul(deltaAt));
            dWdt = dWdt.add(fixedFeat.mmul(deltaAt));
            dWtt = dWtt.add(prevT.mmul(deltaAt));
            dWst = dWst.add(s.mmul(deltaAt));
            dbt = dbt.add(deltaAt);
		}
		
		acts.put("dWxt", dWxt);
    	acts.put("dWdt", dWdt);
    	acts.put("dWtt", dWtt);
    	acts.put("dWst", dWst);
    	acts.put("dbt", dbt);
		
		acts.put("dV", dV);
		acts.put("dU", dU);
		acts.put("dW", dW);
		acts.put("dZ", dZ);
		acts.put("dbs", dbs);
	}
	
	private void calcWeightsCovGradient(Map<String, DoubleMatrix> acts, int lastT) {
		
		DoubleMatrix dWvv = new DoubleMatrix(Wvv.rows, Wvv.columns);
    	DoubleMatrix dWav = new DoubleMatrix(Wav.rows, Wav.columns);
    	DoubleMatrix dWhv = new DoubleMatrix(Whv.rows, Whv.columns);
    	DoubleMatrix dWtv = new DoubleMatrix(Wtv.rows, Wtv.columns);
    	DoubleMatrix dbv = new DoubleMatrix(bv.rows, bv.columns);

    	for(int t=0; t<lastT+1; t++) { // no need to calculate the last one
			DoubleMatrix deltaGV = acts.get("dgV"+t);
			
			DoubleMatrix vecV = acts.get("v"+t);
			DoubleMatrix deltaGVevV = deltaGV.mul(deriveExp(vecV));
			
			int bsIdx = Math.max(0, t-AlgConsHSoftmax.windowSize+1);
			
			DoubleMatrix prevT = null;
			DoubleMatrix prevV = null;
			DoubleMatrix prevAlpha = null;
			if(t>0) {
				prevT = acts.get("t"+(t-1));
				prevV = acts.get("v"+(t-1));
				prevAlpha = acts.get("alpha"+(t-1));
			} else {
				prevT = DoubleMatrix.zeros(1, hiddenSize);
				prevV = DoubleMatrix.zeros(1, covSize);
				prevAlpha = DoubleMatrix.zeros(1);
			}

			int biasPos = bsIdx>0?1:0;
			for(int k=bsIdx; k<t+1; k++) {
				DoubleMatrix hk = acts.get("h"+k).transpose();
				if(k<t) {
					dWvv = dWvv.add(prevV.getRow(k-bsIdx+biasPos).transpose().mmul(deltaGVevV.getRow(k-bsIdx)));
					dWav = dWav.add(deltaGVevV.getRow(k-bsIdx).mul(prevAlpha.get(k-bsIdx+biasPos)));
				}
				dWhv = dWhv.add(hk.mmul(deltaGVevV.getRow(k-bsIdx)));
				dWtv = dWtv.add(prevT.transpose().mmul(deltaGVevV.getRow(k-bsIdx)));
				dbv = dbv.add(deltaGVevV.getRow(k-bsIdx));
			}
		}
		
		acts.put("dWvv", dWvv);
    	acts.put("dWav", dWav);
    	acts.put("dWhv", dWhv);
    	acts.put("dWtv", dWtv);
    	acts.put("dbv", dbv);
	}
	
	public void updateParametersByAdaGrad(BatchDerivative derv, double lr) {
    	
		AttWithCovBatchDerivative batchDerv = (AttWithCovBatchDerivative)derv;
    	
    	hdWxt = hdWxt.add(MatrixFunctions.pow(batchDerv.dWxt, 2.));
    	hdWdt = hdWdt.add(MatrixFunctions.pow(batchDerv.dWdt, 2.));
    	hdWtt = hdWtt.add(MatrixFunctions.pow(batchDerv.dWtt, 2.));
    	hdWst = hdWst.add(MatrixFunctions.pow(batchDerv.dWst, 2.));
    	hdbt = hdbt.add(MatrixFunctions.pow(batchDerv.dbt, 2.));
    	
        hdV = hdV.add(MatrixFunctions.pow(batchDerv.dV, 2.));
        hdU = hdU.add(MatrixFunctions.pow(batchDerv.dU, 2.));
        hdW = hdW.add(MatrixFunctions.pow(batchDerv.dW, 2.));
        hdZ = hdZ.add(MatrixFunctions.pow(batchDerv.dZ, 2.));
        hdbs = hdbs.add(MatrixFunctions.pow(batchDerv.dbs, 2.));
        
        hdWvv = hdWvv.add(MatrixFunctions.pow(batchDerv.dWvv, 2.));
    	hdWav = hdWav.add(MatrixFunctions.pow(batchDerv.dWav, 2.));
    	hdWhv = hdWhv.add(MatrixFunctions.pow(batchDerv.dWhv, 2.));
    	hdWtv = hdWtv.add(MatrixFunctions.pow(batchDerv.dWtv, 2.));
    	hdbv = hdbv.add(MatrixFunctions.pow(batchDerv.dbv, 2.));
    	
        Wvv = Wvv.sub(batchDerv.dWvv.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWvv).add(eps),-1.).mul(lr)));
		Wav = Wav.sub(batchDerv.dWav.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWav).add(eps),-1.).mul(lr)));
		Whv = Whv.sub(batchDerv.dWhv.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWhv).add(eps),-1.).mul(lr)));
		Wtv = Wtv.sub(batchDerv.dWtv.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWtv).add(eps),-1.).mul(lr)));
		bv = bv.sub(batchDerv.dbv.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdbv).add(eps),-1.).mul(lr)));
        
        Wxt = Wxt.sub(batchDerv.dWxt.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWxt).add(eps),-1.).mul(lr)));
		Wdt = Wdt.sub(batchDerv.dWdt.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWdt).add(eps),-1.).mul(lr)));
		Wtt = Wtt.sub(batchDerv.dWtt.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWtt).add(eps),-1.).mul(lr)));
		Wst = Wst.sub(batchDerv.dWst.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdWst).add(eps),-1.).mul(lr)));
		bt = bt.sub(batchDerv.dbt.mul(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hdbt).add(eps),-1.).mul(lr)));
        
        V = V.sub(batchDerv.dV.mul(
        		MatrixFunctions.pow(MatrixFunctions.sqrt(hdV).add(eps),-1.).mul(lr)));
        U = U.sub(batchDerv.dU.mul(
        		MatrixFunctions.pow(MatrixFunctions.sqrt(hdU).add(eps),-1.).mul(lr)));
        W = W.sub(batchDerv.dW.mul(
        		MatrixFunctions.pow(MatrixFunctions.sqrt(hdW).add(eps),-1.).mul(lr)));
        Z = Z.sub(batchDerv.dZ.mul(
        		MatrixFunctions.pow(MatrixFunctions.sqrt(hdZ).add(eps),-1.).mul(lr)));
        bs = bs.sub(batchDerv.dbs.mul(
        		MatrixFunctions.pow(MatrixFunctions.sqrt(hdbs).add(eps),-1.).mul(lr)));
    }
    
    public void updateParametersByAdam(BatchDerivative derv, double lr
    						, double beta1, double beta2, int epochT) {
    	
    	AttWithCovBatchDerivative batchDerv = (AttWithCovBatchDerivative)derv;

		double biasBeta1 = 1. / (1 - Math.pow(beta1, epochT));
		double biasBeta2 = 1. / (1 - Math.pow(beta2, epochT));

		hd2Wxt = hd2Wxt.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWxt, 2.).mul(1 - beta2));
		hd2Wdt = hd2Wdt.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWdt, 2.).mul(1 - beta2));
		hd2Wtt = hd2Wtt.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWtt, 2.).mul(1 - beta2));
		hd2Wst = hd2Wst.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWst, 2.).mul(1 - beta2));
		hd2bt = hd2bt.mul(beta2).add(MatrixFunctions.pow(batchDerv.dbt, 2.).mul(1 - beta2));
		
		hdWxt = hdWxt.mul(beta1).add(batchDerv.dWxt.mul(1 - beta1));
		hdWdt = hdWdt.mul(beta1).add(batchDerv.dWdt.mul(1 - beta1));
		hdWtt = hdWtt.mul(beta1).add(batchDerv.dWtt.mul(1 - beta1));
		hdWst = hdWst.mul(beta1).add(batchDerv.dWst.mul(1 - beta1));
		hdbt = hdbt.mul(beta1).add(batchDerv.dbt.mul(1 - beta1));
		
		hd2V = hd2V.mul(beta2).add(MatrixFunctions.pow(batchDerv.dV, 2.).mul(1 - beta2));
		hd2U = hd2U.mul(beta2).add(MatrixFunctions.pow(batchDerv.dU, 2.).mul(1 - beta2));
		hd2W = hd2W.mul(beta2).add(MatrixFunctions.pow(batchDerv.dW, 2.).mul(1 - beta2));
		hd2Z = hd2Z.mul(beta2).add(MatrixFunctions.pow(batchDerv.dZ, 2.).mul(1 - beta2));
		hd2bs = hd2bs.mul(beta2).add(MatrixFunctions.pow(batchDerv.dbs, 2.).mul(1 - beta2));
		
		hdV = hdV.mul(beta1).add(batchDerv.dV.mul(1 - beta1));
		hdU = hdU.mul(beta1).add(batchDerv.dU.mul(1 - beta1));
		hdW = hdW.mul(beta1).add(batchDerv.dW.mul(1 - beta1));
		hdZ = hdZ.mul(beta1).add(batchDerv.dZ.mul(1 - beta1));
		hdbs = hdbs.mul(beta1).add(batchDerv.dbs.mul(1 - beta1));

		hd2Wvv = hd2Wvv.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWvv, 2.).mul(1 - beta2));
		hd2Wav = hd2Wav.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWav, 2.).mul(1 - beta2));
		hd2Whv = hd2Whv.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWhv, 2.).mul(1 - beta2));
		hd2Wtv = hd2Wtv.mul(beta2).add(MatrixFunctions.pow(batchDerv.dWtv, 2.).mul(1 - beta2));
		hd2bv = hd2bv.mul(beta2).add(MatrixFunctions.pow(batchDerv.dbv, 2.).mul(1 - beta2));
		
		hdWvv = hdWvv.mul(beta1).add(batchDerv.dWvv.mul(1 - beta1));
		hdWav = hdWav.mul(beta1).add(batchDerv.dWav.mul(1 - beta1));
		hdWhv = hdWhv.mul(beta1).add(batchDerv.dWhv.mul(1 - beta1));
		hdWtv = hdWtv.mul(beta1).add(batchDerv.dWtv.mul(1 - beta1));
		hdbv = hdbv.mul(beta1).add(batchDerv.dbv.mul(1 - beta1));
		
		Wvv = Wvv.sub(
				hdWvv.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wvv.mul(biasBeta2)).add(eps), -1))
				);
		Wav = Wav.sub(
				hdWav.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wav.mul(biasBeta2)).add(eps), -1))
				);
		Whv = Whv.sub(
				hdWhv.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Whv.mul(biasBeta2)).add(eps), -1))
				);
		Wtv = Wtv.sub(
				hdWtv.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wtv.mul(biasBeta2)).add(eps), -1))
				);
		bv = bv.sub(
				hdbv.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2bv.mul(biasBeta2)).add(eps), -1))
				);
		
		Wxt = Wxt.sub(
				hdWxt.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wxt.mul(biasBeta2)).add(eps), -1))
				);
		Wdt = Wdt.sub(
				hdWdt.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wdt.mul(biasBeta2)).add(eps), -1))
				);
		Wtt = Wtt.sub(
				hdWtt.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wtt.mul(biasBeta2)).add(eps), -1))
				);
		Wst = Wst.sub(
				hdWst.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Wst.mul(biasBeta2)).add(eps), -1))
				);
		bt = bt.sub(
				hdbt.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2bt.mul(biasBeta2)).add(eps), -1))
				);
		V = V.sub(
					hdV.mul(biasBeta1).mul(lr)
					.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2V.mul(biasBeta2)).add(eps), -1))
					);
		U = U.sub(
				hdU.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2U.mul(biasBeta2)).add(eps), -1))
				);
		W = W.sub(
				hdW.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2W.mul(biasBeta2)).add(eps), -1))
				);
		Z = Z.sub(
				hdZ.mul(biasBeta1).mul(lr)
				.mul(MatrixFunctions.pow(MatrixFunctions.sqrt(hd2Z.mul(biasBeta2)).add(eps), -1))
				);
		bs = bs.sub(
				MatrixFunctions.pow(MatrixFunctions.sqrt(hd2bs.mul(biasBeta2)).add(eps), -1.)
				.mul(hdbs.mul(biasBeta1)).mul(lr)
				);
    }

	/* (non-Javadoc)
	 * @see com.kingwang.cdmrnn.rnn.Cell#writeCellParameter(java.lang.String, boolean)
	 */
	@Override
	public void writeCellParameter(String outFile, boolean isAttached) {
		OutputStreamWriter osw = FileUtil.getOutputStreamWriter(outFile, isAttached);
		FileUtil.writeln(osw, "Wxt");
		writeMatrix(osw, Wxt);
		FileUtil.writeln(osw, "Wdt");
		writeMatrix(osw, Wdt);
		FileUtil.writeln(osw, "Wtt");
		writeMatrix(osw, Wtt);
		FileUtil.writeln(osw, "Wst");
		writeMatrix(osw, Wst);
		FileUtil.writeln(osw, "bt");
		writeMatrix(osw, bt);
    	FileUtil.writeln(osw, "W");
    	writeMatrix(osw, W);
    	FileUtil.writeln(osw, "U");
    	writeMatrix(osw, U);
    	FileUtil.writeln(osw, "V");
    	writeMatrix(osw, V);
    	FileUtil.writeln(osw, "Z");
    	writeMatrix(osw, Z);
    	FileUtil.writeln(osw, "bs");
    	writeMatrix(osw, bs);
    	FileUtil.writeln(osw, "Wvv");
		writeMatrix(osw, Wvv);
		FileUtil.writeln(osw, "Wav");
		writeMatrix(osw, Wav);
		FileUtil.writeln(osw, "Whv");
		writeMatrix(osw, Whv);
		FileUtil.writeln(osw, "Wtv");
		writeMatrix(osw, Wtv);
		FileUtil.writeln(osw, "bv");
		writeMatrix(osw, bv);
	}

	/* (non-Javadoc)
	 * @see com.kingwang.cdmrnn.rnn.Cell#loadCellParameter(java.lang.String)
	 */
	@Override
	public void loadCellParameter(String cellParamFile) {
		LoadTypes type = LoadTypes.Null;
		int row = 0;
		
		try(BufferedReader br = FileUtil.getBufferReader(cellParamFile)) {
			String line = null;
			while((line=br.readLine())!=null) {
				String[] elems = line.split(",");
				if(elems.length<2 && !elems[0].contains(".")) {
					String typeStr = "Null";
    				String[] typeList = {"W", "U", "V", "Z", "bs", "Wxt", "Wdt", "Wtt", "Wst", "bt"
    										, "Wvv", "Wav", "Whv", "Wtv", "bv"};
    				for(String tStr : typeList) {
    					if(elems[0].equalsIgnoreCase(tStr)) {
    						typeStr = tStr;
    						break;
    					}
    				}
    				type = LoadTypes.valueOf(typeStr);
					row = 0;
					continue;
				}
				switch(type) {
					case Wxt: this.Wxt = matrixSetter(row, elems, this.Wxt); break;
					case Wdt: this.Wdt = matrixSetter(row, elems, this.Wdt); break;
					case Wtt: this.Wtt = matrixSetter(row, elems, this.Wtt); break;
					case Wst: this.Wst = matrixSetter(row, elems, this.Wst); break;
					case bt: this.bt = matrixSetter(row, elems, this.bt); break;
					case W: this.W = matrixSetter(row, elems, this.W); break;
					case U: this.U = matrixSetter(row, elems, this.U); break;
					case V: this.V = matrixSetter(row, elems, this.V); break;
					case Z: this.Z = matrixSetter(row, elems, this.Z); break;
					case bs: this.bs = matrixSetter(row, elems, this.bs); break;
					case Wvv: this.Wvv = matrixSetter(row, elems, this.Wvv); break;
					case Wav: this.Wav = matrixSetter(row, elems, this.Wav); break;
					case Whv: this.Whv = matrixSetter(row, elems, this.Whv); break;
					case Wtv: this.Wtv = matrixSetter(row, elems, this.Wtv); break;
					case bv: this.bv = matrixSetter(row, elems, this.bv); break;
				}
				row++;
			}
			
		} catch(IOException e) {
			
		}
	}
}
