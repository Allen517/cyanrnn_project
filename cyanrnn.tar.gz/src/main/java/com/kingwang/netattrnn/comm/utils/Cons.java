/**   
 * @package	utils
 * @File		Cons.java
 * @Crtdate	Mar 18, 2016
 *
 * Copyright (c) 2016 by <a href="mailto:wangyongqing.casia@gmail.com">King Wang</a>.   
 */
package com.kingwang.netattrnn.comm.utils;

/**
 *
 * @author King Wang
 * 
 * Mar 18, 2016 2:24:38 PM
 * @version 1.0
 */
public class Cons {

	public static String timeFormat = "yyyy-MM-dd HH:mm:ss";
}
